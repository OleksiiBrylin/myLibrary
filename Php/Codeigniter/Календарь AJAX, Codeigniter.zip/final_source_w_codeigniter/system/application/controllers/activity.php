<?php

class Activity extends MY_Controller {

	public function Activity()
	{
		parent::MY_Controller();
	}

	// check the date and if valid, reformat it 
	private function _check_date(&$date_str) {

		if ( ! preg_match("|([0-9]{1,2})/([0-9]{1,2})/([0-9]{4})|", $date_str)) {
			return FALSE;
		}

		$date_array = split("/", $date_str);
		$month = $date_array[0];
		$day = $date_array[1];
		$year = $date_array[2];
		
		if ( ! checkdate($month, $day, $year)) {
			return FALSE;
		}
		
		$date_str = date('Y-m-d', mktime(0, 0, 0, $month, $day, $year));
		return TRUE;
	}

	public function user_class_listing()
	{
		// if posted with a participation_type_id, set the user participation and redisplay the page
		if (isset($_POST['participation_type_id'])) {
		
			$this->load->model('MActivity', '', TRUE);
			$this->MActivity->set_user_participation($_POST);
			$data['success_message'] = '<p>Class activity participation successfully saved.</p>';
		}

		// if not posted, simply load the page
		$this->load->library('table');
		
		$this->load->model('MActivity','',TRUE);
		$activities_qry = $this->MActivity->list_user_class_activities();
		$participation_qry = $this->MActivity->get_participation_types();
		
		// generate HTML table from query results
		$tmpl = array (
			'table_open' => '<table>',
			'heading_row_start' => '<tr class="table_header">',
			'row_start' => '<tr class="odd_row">' 
		);
		$this->table->set_template($tmpl); 
		
		$this->table->set_empty("&nbsp;"); 
		
		$this->table->set_heading('<span class="date_column">Date</span>',
								  '<span class="activity_name_column">Activity Name</span>',
								  '<span class="address_column">Address</span>',
								  'City', 'Your Participation');
		
		
		$table_row = array();
		
		foreach ($activities_qry->result() as $activity)
		{

			$table_row = NULL;
			$table_row[] = date('M. d, Y', strtotime($activity->date));
			$table_row[] = htmlspecialchars($activity->name);
			$table_row[] = htmlspecialchars($activity->address);
			$table_row[] = htmlspecialchars($activity->city);

			$participation_type_buttons = NULL;
			foreach ($participation_qry->result() as $participation_type) {
				if ((!isset($activity->participation_type_id)) && ($participation_type->id == 1) OR 
					($activity->participation_type_id == $participation_type->id)) {

					$participation_type_buttons .= '<input type="radio" name="participation_type_id" value="';
					$participation_type_buttons .= $participation_type->id.'" ';
					$participation_type_buttons .= 'checked="checked" ';
					$participation_type_buttons .= '/> ';
	
					$participation_type_buttons .= '<span class="check">';
					$participation_type_buttons .= $participation_type->name;
					$participation_type_buttons .= '</span> ';
				} else {

					$participation_type_buttons .= '<input type="radio" name="participation_type_id" value="';
					$participation_type_buttons .= $participation_type->id.'" ';
					$participation_type_buttons .= '/> ';
	
					$participation_type_buttons .= '<span class="">';
					$participation_type_buttons .= $participation_type->name;
					$participation_type_buttons .= '</span> ';
				}
			}
			
			$table_row[] = '<form action="" name="form_'.$activity->id.'" method="post">'.
				'<input type="hidden" name="class_activity_id" value="'.$activity->id.'" />'.
				'<input type="hidden" name="user_id" value="'.$this->session->userdata('uid').'" />'.
				'<span style="white-space: nowrap;">'.
				$participation_type_buttons.'&nbsp;&nbsp;'.
				/* the save link is no longer needed
					'<a href="" onclick="document.forms[\'form_'.$activity->id.'\'].submit();
return false;">save</a>'. */
				'</span>'.
				'</form>';
			
			$this->table->add_row($table_row);
		}    
		
		$activities_table = $this->table->generate();
		
		// display information for the view
		$data['title'] = "Classroom: Activity Listing";
		$data['headline'] = "Class Activity Listing";
		$data['include'] = 'activity_listing';
		$data['uid'] = $this->session->userdata('uid');
		$data['is_admin'] = $this->session->userdata('is_admin');
		
		$data['data_table'] = $activities_table;
		
		$this->load->view('template', $data);
	}
	
	public function manage_class_listing()
	{
		$this->load->model('MActivity','',TRUE);
		$this->load->library('table');

		// if posted with a participation_type_id, set the user participation and redisplay the page
		if (isset($_POST['action'])) {
			
			$this->load->model('MActivity', '', TRUE);
			
			switch ($_POST['action']){
				case "save":
					$activity_date = $_POST['activity_date'];
					if ($this->_check_date($activity_date)) {
						$post_data = array();
						$post_data['master_activity_id'] = $_POST['master_activity_id'];
						$post_data['date'] = $activity_date;
						$this->MActivity->save_class_activity($post_data);
						$data['success_message'] = '<p>Class activity date successfully saved.</p>';
					} else {
						$data['error_message'] = '<p>The date "'.$_POST['activity_date'].'" is not a valid date or date format. Data was not saved.</p>';
					}
					break;
				
				case "update":
					$activity_date = $_POST['activity_date'];
					if ($this->_check_date($activity_date)) {
						$post_data = array();
						$post_data['date'] = $activity_date;
						$id = $_POST['class_activity_id'];
						$this->MActivity->update_class_activity($id, $post_data);
						$data['success_message'] = '<p>Class activity updated successfully.</p>';
					} else {
						$data['error_message'] = '<p>The date "'.$_POST['activity_date'].'" is not a valid date or date format. Data was not saved.</p>';
					}
					break;
				
				case "edit":
					$master_requested_id = $_POST['master_activity_id'];
					$requested_activity_id = $_POST['class_activity_id'];
					$requested_activity_qry = $this->MActivity->get_requested_class_activity($requested_activity_id);
				break;
				
				case "delete":
					$this->MActivity->delete_class_activity($_POST['class_activity_id']);
					$data['success_message'] = '<p>Class activity successfully deleted.</p>';
					break;
			}
		}
		
		// if not posted, simply load the page
		
		
		// if we have a requested activity - show it before the results array
		if (isset($requested_activity_id)) {

			// generate HTML table from query results
			$tmpl = array (
				'table_open' => '<table>',
				'heading_row_start' => '<tr class="table_header_edit">',
				'row_start' => '<tr class="odd_row_edit">' 
			);
			$this->table->set_template($tmpl); 
			
			$this->table->set_caption('&nbsp;Edit this Activity'); 

			$this->table->set_empty("&nbsp;"); 
			
			$this->table->set_heading('<span class="date_column">Date</span>',
									  '<span class="activity_name_column">Activity Name</span>',
									  '<span class="address_column">Address</span>',
									  'City', 'Details');
			
			$table_row = array();
	
			foreach ($requested_activity_qry->result() as $activity)
			{
				$table_row = NULL;
	
				$table_row[] = ''.
					'<form action="" name="form_'.$activity->master_activity_id.'" method="post">'.
					'<input type="hidden" name="master_activity_id" value="'.$activity->master_activity_id.'"/> '.
					'<input type="hidden" name="class_activity_id" value="'.$activity->class_activity_id.'"/> '.
					// add the date-picker class to the date input field
					'<input type="text" name="activity_date" size="12" value="'.
						date('m/d/Y', strtotime($activity->date)).'" class="date-picker" /> '.
					'<input type="hidden" name="action" value="update" /> '.
					'</form>'.
					'<span class="help-text">format: MM/DD/YYYY</span><br/>'.
					'<a href="" onclick="document.forms[\'form_'.$activity->master_activity_id.'\'].submit(); return false;">update</a>';
				
				$table_row[] = $activity->name;
				$table_row[] = $activity->address;
				$table_row[] = $activity->city;
				$table_row[] = $activity->details;
	
				$this->table->add_row($table_row);
			}    
			
			$requested_activities_table = $this->table->generate();
			$this->table->clear();
		} else {
			$requested_activities_table = NULL;
		}


		// if we have shown a requested record already, omit that from the results set
		if (isset($master_requested_id)) {
			$activities_qry = $this->MActivity->list_class_activities($master_requested_id);
		// else omit nothing from the results set
		} else {
			$activities_qry = $this->MActivity->list_class_activities(NULL);
		}


		// generate HTML table from query results
		$tmpl = array (
			'table_open' => '<table>',
			'heading_row_start' => '<tr class="table_header">',
			'row_start' => '<tr class="odd_row">' 
		);
		$this->table->set_template($tmpl); 
		
		$this->table->set_caption(NULL); 

		$this->table->set_empty("&nbsp;"); 
		
		$this->table->set_heading('<span class="date_column">Date</span>',
								  '<span class="activity_name_column">Activity Name</span>',
								  '<span class="address_column">Address</span>',
								  'City', 'Details');
		
		$table_row = array();

		foreach ($activities_qry->result() as $activity)
		{
			$table_row = NULL;

			// if there's a date set, show it with edit and delete links
			if ($activity->date != NULL) {
				$table_row[] = ''.
					'<form action="" name="form_'.$activity->master_activity_id.'" method="post">'.
					'<strong>'.date('M. d, Y', strtotime($activity->date)).'</strong>'.
					'<input type="hidden" name="master_activity_id" value="'.$activity->master_activity_id.'"/> '.
					'<input type="hidden" name="class_activity_id" value="'.$activity->class_activity_id.'"/> '.
					'<input type="hidden" name="action" value="" />'.
					'<br />'.
					'<a href="" onclick="document.forms[\'form_'.$activity->master_activity_id.'\'].elements[\'action\'].value=\'edit\'; document.forms[\'form_'.$activity->master_activity_id.'\'].submit(); return false;">edit</a> | '.
					'<a href="" onclick="if (confirm(\'Are you sure you want to delete the record for '.addslashes($activity->name).'?\')) {document.forms[\'form_'.$activity->master_activity_id.'\'].elements[\'action\'].value=\'delete\'; document.forms[\'form_'.$activity->master_activity_id.'\'].submit();} return false;">delete</a>'.
					'</form>';
			// if there's no date set, show an input field with a submit link
			} else {
				$table_row[] = ''.
					'<form action="" name="form_'.$activity->master_activity_id.'" method="post">'.
					'<input type="hidden" name="master_activity_id" value="'.$activity->master_activity_id.'"/> '.
					'<input type="text" name="activity_date" size="12" /> '.
					'<input type="hidden" name="action" value="save" /> '.
					'</form>'.
					'<span class="help-text">format: MM/DD/YYYY</span><br/>'.
					'<a href="" onclick="document.forms[\'form_'.$activity->master_activity_id.'\'].submit(); return false;">save</a>';
			}
			
			$table_row[] = htmlspecialchars($activity->name);
			$table_row[] = htmlspecialchars($activity->address);
			$table_row[] = htmlspecialchars($activity->city);
			$table_row[] = htmlspecialchars($activity->details);

			$this->table->add_row($table_row);
		}    
		
		$activities_table = $this->table->generate();
		
		// display information for the view
		$data['title'] = "Classroom: Activity Listing";
		$data['headline'] = "Master Activity Listing";
		$data['include'] = 'activity_master_listing';
		$data['uid'] = $this->session->userdata('uid');
		$data['is_admin'] = $this->session->userdata('is_admin');
		
		$data['data_table'] = $activities_table;
		$data['requested_data_table'] = $requested_activities_table;
		
		$this->load->view('template', $data);
	}
	
	public function master_delete()
	{
		$id = $this->uri->segment(3);
		
		$this->load->model('MActivity','',TRUE);
		$this->MActivity->delete_master_activity($id);
		redirect('activity/master_listing','refresh');
	}

}
/* End of file activity.php */
/* Location: ./system/application/controllers/acitvity.php */