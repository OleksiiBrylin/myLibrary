<?php

class Ajax extends Controller {

	public function Ajax() {
	
		parent::Controller(); 
    }

	public function username_taken()
	{
		$this->load->model('MUser', '', TRUE);
		$username = trim($_POST['username']);
		// if the username exists echo a '1' indicating true
		if ($this->MUser->username_exists($username)) {
			echo '1';
		}
	}

	public function update_user_participation()
	{
		$this->load->model('MActivity', '', TRUE);
		$this->MActivity->set_user_participation($_POST);
	}
	

	public function autosuggest()
	{
		// escapes single and double quotes
		$str = addslashes($_POST['str']);
		
		$this->load->model('MActivity', '', TRUE);
		$unscheduled_activities_qry = $this->MActivity->find_unscheduled_activities($str);
		
		// echo a list where each li has a set_activity function bound to its onclick() event
		echo '<ul>';
		foreach ($unscheduled_activities_qry->result() as $activity) {
			echo '<li onclick="set_activity(\''.addslashes($activity->name).'\'';
			echo ', '.$activity->id.');">'.$activity->name.'</li>'; 
		}
		echo '</ul>';
	}	

	public function get_activity_html()
	{
		$this->load->model('MActivity', '', TRUE);
		$this->load->library('table');

		$requested_activity_id = $_POST['master_activity_id'];
		$requested_activity_qry = 
			$this->MActivity->get_requested_master_activity($requested_activity_id);

		// code leveraged from /controllers/activity.php manage_class_listing() method
		// generate HTML table from query results
		$tmpl = array (
			'table_open' => '<table>',
			'heading_row_start' => '<tr class="table_header_add">',
			'row_start' => '<tr class="odd_row_add">' 
		);
		$this->table->set_template($tmpl); 
		
		$this->table->set_caption('&nbsp;Add this Activity'); 

		$this->table->set_empty("&nbsp;"); 
		
		$this->table->set_heading('<span class="date_column">Date</span>',
								  '<span class="activity_name_column">Activity Name</span>',
								  '<span class="address_column">Address</span>',
								  'City', 'Details');
		
		$table_row = array();

		foreach ($requested_activity_qry->result() as $activity)
		{
			$m_id = $activity->master_activity_id;

			$table_row = NULL;

			$table_row[] = ''.
				'<form action="" name="form_'.$m_id.'" method="post">'.
				'<input type="hidden" name="master_activity_id" value="'.$m_id.'"/> '.
				// add the date-picker class to the date input field
				'<input type="text" name="activity_date" size="12" class="date-picker" /> '.
				'<input type="hidden" name="action" value="save" /> '.
				'</form>'.
				'<span class="help-text">format: MM/DD/YYYY</span><br/>'.
				'<a href="" onclick="document.forms[\'form_'.$m_id.'\'].submit();'.
				'return false;">save</a>';


			$table_row[] = '<input type="text" value="'.$activity->name.
				'" id="class_activity" onkeyup="autosuggest(this.value);"'.
				'class="autosuggest_input" />'.
				'<div class="autosuggest" id="autosuggest_list"></div>';
			$table_row[] = htmlspecialchars($activity->address);
			$table_row[] = htmlspecialchars($activity->city);
			$table_row[] = htmlspecialchars($activity->details);

			$this->table->add_row($table_row);
		}    
			
		$requested_activities_table = $this->table->generate();

		echo $requested_activities_table;
	}

}

/* End of file ajax.php */
/* Location: ./system/application/controllers/ajax.php */