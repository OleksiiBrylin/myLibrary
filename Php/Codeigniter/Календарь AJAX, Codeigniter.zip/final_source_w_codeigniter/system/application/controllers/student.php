<?php

class Student extends MY_Controller {
	
	public function Student()
	{
		parent::MY_Controller();
	}
	
	public function index()
	{
		// redirect to the listing page
		$this->listing();
	}
	
	public function add()
	{
		$this->load->helper('form');
		
		// display information for the view
		$data['title'] = "Classroom: Add Student";
		$data['headline'] = "Add a New Student";
		$data['include'] = 'student_add';
		$data['uid'] = $this->session->userdata('uid');
		$data['is_admin'] = $this->session->userdata('is_admin');
		
		$this->load->view('template', $data);
	}
	
	public function create()
	{
		$this->load->helper('url');
		
		$this->load->model('MStudent','',TRUE);
		$this->MStudent->add_student($_POST);
		redirect('student/listing','refresh');
	}
	
	public function listing()
	{
		$this->load->library('table');
		
		$this->load->model('MStudent','',TRUE);
		if ($this->session->userdata('is_admin')) {
			$students_qry = $this->MStudent->list_all_students();
		} else {
			$students_qry = $this->MStudent->list_students($this->session->userdata('uid'));
		}
		
		// generate HTML table from query results
		$tmpl = array (
			'table_open' => '<table>',
			'heading_row_start' => '<tr class="table_header">',
			'row_start' => '<tr class="odd_row">' 
		);
		$this->table->set_template($tmpl); 
		
		$this->table->set_empty("&nbsp;"); 
		
		$this->table->set_heading('', 'Child Name', 'Parent Name', 'Address', 
			'City', 'State', 'Zip', 'Phone', 'Email');
		
		$table_row = array();
		foreach ($students_qry->result() as $student) {

			$table_row = NULL;
			$table_row[] = '<span style="white-space: nowrap">' . 
			anchor('student/edit/' . $student->id, 'edit') . ' | ' .
			anchor('student/delete/' . $student->id, 'delete',
				"onclick=\" return confirm('Are you sure you want to '
				+ 'delete the record for ".addslashes($student->s_name)."?')\"") .
				'</span>';

			$table_row[] = htmlspecialchars($student->s_name);
			$table_row[] = htmlspecialchars($student->p_name);
			$table_row[] = htmlspecialchars($student->address);
			$table_row[] = htmlspecialchars($student->city);
			$table_row[] = $student->state;
			$table_row[] = $student->zip;
			$table_row[] = $student->phone;
			$table_row[] = mailto($student->email);
			
			$this->table->add_row($table_row);
		}    
		
		$students_table = $this->table->generate();
		
		// display information for the view
		$data['title'] = "Classroom: Student Listing";
		$data['headline'] = "Student Listing";
		$data['include'] = 'student_listing';
		$data['uid'] = $this->session->userdata('uid');
		$data['is_admin'] = $this->session->userdata('is_admin');
		
		$data['data_table'] = $students_table;
		
		$this->load->view('template', $data);
	}
		
	public function edit()
	{
		$this->load->helper('form');
		
		$id = $this->uri->segment(3);
		$this->load->model('MStudent','',TRUE);
		$data['row'] = $this->MStudent->get_student($id)->result();
		
		// display information for the view
		$data['title'] = "Classroom: Edit Student";
		$data['headline'] = "Edit Student Information";
		$data['include'] = 'student_edit';
		$data['uid'] = $this->session->userdata('uid');
		$data['is_admin'] = $this->session->userdata('is_admin');
		
		$this->load->view('template', $data);
	}
	
	public function update()
	{
		$this->load->model('MStudent','',TRUE);
		$this->MStudent->update_student($_POST['id'], $_POST);
		redirect('student/listing','refresh');
	}
	
	public function delete()
	{
		$id = $this->uri->segment(3);
		
		$this->load->model('MStudent','',TRUE);
		$this->MStudent->delete_student($id);
		redirect('student/listing','refresh');
	}

}
/* End of file student.php */
/* Location: ./system/application/controllers/student.php */