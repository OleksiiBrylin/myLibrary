<?php 

class MStudent extends Model {

	// Create student record in database
	public function add_student($data)
	{
		$this->db->insert('student', $data);
	}
	
	// Retrieve student records related to $uid
	public function list_students($uid)
	{
	
		return $this->db->get_where('student', array('user_id'=> $uid));
	}
	
	// Retrieve all student records 
	public function list_all_students()
	{
	
		return $this->db->get('student');
	}
	
	// Retrieve one student record
	public function get_student($id)
	{
		return $this->db->get_where('student', array('id'=> $id));
	}
	
	// Update one student record
	public function update_student($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('student', $data); 
	}
	
	// Delete one student record
	public function delete_student($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('student'); 
	}
	
}
/* End of file mstudent.php */
/* Location: ./system/application/models/mstudent.php */