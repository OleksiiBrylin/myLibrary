<?php 

class MActivity extends Model{

	// Retrieve all master activity records
	function list_class_activities($activity_id)
	{
		// get all records
		if (!$activity_id) {
			$this->db->select('ma.id as master_activity_id, ma.name, 
							  ma.address, ma.city, 
							  ma.details, ca.id as class_activity_id, ca.date
					  FROM master_activity ma
					  /*LEFT*/ JOIN class_activity ca ON ca.master_activity_id = ma.id
					  ORDER BY ca.date /*DESC*/, ma.name', FALSE);
			return $this->db->get();
		// get all records except the one being requested
		} else {
			$this->db->select('ma.id as master_activity_id, ma.name, 
							  ma.address, ma.city, 
							  ma.details, ca.id as class_activity_id, ca.date
					  FROM (SELECT * FROM master_activity 
							WHERE master_activity.id != '.$activity_id.') ma
					  /*LEFT*/ JOIN class_activity ca ON ca.master_activity_id = ma.id
					  ORDER BY ca.date /*DESC*/, ma.name', FALSE);
			return $this->db->get();
		}
	}

	// Retrieve the one requested record for edit
	function get_requested_class_activity($activity_id)
	{
		$this->db->select('ma.id as master_activity_id, ma.name, 
						  ma.address, ma.city, 
						  ma.details, ca.id as class_activity_id, ca.date
				  FROM (SELECT * FROM class_activity 
						WHERE class_activity.id = '.$activity_id.') ca
				  JOIN master_activity ma ON ma.id = ca.master_activity_id
				  ORDER BY ca.date DESC, ma.name', FALSE);
		return $this->db->get();
	}

	// Retrieve all participation type names
	function get_participation_types()
	{
		return $this->db->get('participation_type');
	}

	// Retrieve all class activity records
	function list_user_class_activities()
	{
		$this->db->select('master_activity.name, master_activity.address, master_activity.city,
					  class_activity.id, class_activity.date, uca.participation_type_id
					  FROM (SELECT * FROM user_class_activity 
							WHERE user_class_activity.user_id = '.$this->session->userdata('uid').') uca
					  RIGHT JOIN class_activity ON uca.class_activity_id = class_activity.id
					  JOIN master_activity ON master_activity.id = class_activity.master_activity_id
					  ORDER BY class_activity.date ASC , master_activity.name', FALSE);
		return $this->db->get();
	}

	// Insert or Update a user's participation on a specific activity
	function set_user_participation($data)
	{
		$class_activity_id = $data['class_activity_id'];
		$user_id = $data['user_id'];
		$this->db->select('id');
		$this->db->where('class_activity_id', $class_activity_id);
		$this->db->where('user_id', $user_id);
		$this->db->from('user_class_activity');
		$query = $this->db->get();

		// if there is a record, then update it otherwise insert it
		if ($query->num_rows() > 0) {
			$row = $query->row();
			$this->db->where('id', $row->id);
			$this->db->update('user_class_activity', $data); 			
		} else {
			$this->db->insert('user_class_activity', $data);
		}
	}


	// Create a class activity record in database
	function save_class_activity($data)
	{
		$this->db->insert('class_activity', $data);
	}

	// Update one activity record
	function update_class_activity($id, $data)
	{
		$this->db->where('id', $id);
		$this->db->update('class_activity', $data); 
	}

	// Delete all user_class_activity records for the selected class_activity
	// and the one class_activity record
	function delete_class_activity($id)
	{
		$this->db->where('class_activity_id', $id);
		$this->db->delete('user_class_activity'); 

		$this->db->where('id', $id);
		$this->db->delete('class_activity'); 
	}

	// Finds all unscheduled activities that match the passed string
	function find_unscheduled_activities($str)
	{
		$this->db->select('id, name
				FROM master_activity 
				WHERE name LIKE \''.$str.'%\'
					AND id NOT IN 
						(SELECT master_activity_id FROM class_activity)
				  ORDER BY name', FALSE);
		return $this->db->get();
	}
	
	// Returns a single master activity record
	public function get_requested_master_activity($id)
	{
		$this->db->select('id as master_activity_id, name, address, city, details');
		$this->db->where('id', $id);
		return $this->db->get('master_activity');
	}
}

/* End of file mactivity.php */
/* Location: ./system/application/models/mactivity.php */
