<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link href="/assets/css/screen.css" rel="stylesheet" type="text/css" />

<!--  the following two lines load the JQuery library and JavaScript files -->
<script src="/assets/js/jquery-1.4.2.js" type="text/javascript"></script>
<script src="/assets/js/global.js" type="text/javascript"></script>

<!-- including the jQuery UI Datepicker and styles -->
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"
	type="text/javascript"></script>
<link href="/assets/css/jquery-ui-1.7.2.custom.css" rel="stylesheet" type="text/css" />
<style type="text/css">
	/* JQuery UI sizing override */
	.ui-widget {font-size:1em;}
</style>

<title><?php echo $title;?></title>
</head>
<body>

	<div class="navigation">
	<?php 
		// nav bar
		// loggend in
		if ($uid) {
			if ($is_admin) {
				echo anchor('student/listing', 'List All Students');
				echo (' | ');
				echo anchor('activity/manage_class_listing', 'Manage Class Activities');
				echo (' | ');
			} else {
				echo anchor('student/add', 'Add Your Student');
				echo (' | ');
				echo anchor('student/listing', 'List Your Students');
				echo (' | ');
				echo anchor('activity/user_class_listing', 'List Class Activities');
				echo (' | ');
			}
			echo anchor('user/logout', 'Logout');
		// not logged in
		} else {
			echo anchor('user', 'Login');
			echo (' | ');
			echo anchor('user/register', 'Register');
		}
	?>
	</div>
	
	<h1><?php echo $headline;?></h1>
	<?php if (isset($error_message)) : echo '<div id="error_message">'.$error_message.'</div>'; endif;  ?>
	<?php if (isset($success_message)) : echo '<div id="success_message">'.$success_message.'</div>'; endif;  ?>
	<br />
	<?php $this->load->view($include);?>

</body>
</html>
