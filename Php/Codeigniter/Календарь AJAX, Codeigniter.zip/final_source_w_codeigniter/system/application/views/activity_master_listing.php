<div id="select_anchor">
	<a href="" onclick="$('#select_anchor').hide(100); 
		$('#select_activity').show(100);
		return false;">
		Select an unscheduled Activity to add >></a>
	<br /><br />
</div>
<div id="select_activity" class="requested_activity" style="display:none;">
	<table>
		<caption>&nbsp;Select an unscheduled Activity</caption>
		<tr class="odd_row_add">
			<td>
				Begin by typing a few letters of an activity name<br />
				then select from the resulting list<br />
				<br />
				<input type="text" value="" id="class_activity" 
					onkeyup="autosuggest(this.value);" class="autosuggest_input" />
				<div class="autosuggest" id="autosuggest_list"></div>
			</td>
		</tr>
	</table>
</div>

<?php
	if (isset($requested_data_table)) {
		echo '<div id="edit_activity" class="requested_activity">';
		echo $requested_data_table;
		echo '</div>';
	}
	echo $data_table;

/* End of file activity_master_listing.php */
/* Location: ./system/application/views/activity_master_listing.php */