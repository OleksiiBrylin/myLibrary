<?php
	
	echo $data_table;

/* End of file activity_listing.php */
/* Location: ./system/application/views/activity_listing.php */