<?php

class MY_Controller extends Controller {

	public function MY_Controller()	{
		parent::Controller();
		if (!$this->session->userdata('uid')) {
			header('Location: /index.php/user');
		}
	}

}

/* End of file MY_Controller.php */
/* Location: ./system/application/library/MY_Controller.php */
